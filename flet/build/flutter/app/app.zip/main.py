import flet as ft
from login import login_view
from registrar import registrar_view
from mainmenu import menu_principal
from infodetallada import info_detallada
from crud_user import crud_user 
from resetcontraseña import reset_contraseña_view
from abrircamara import abrir_camara

# Función principal que se ejecuta al iniciar la aplicación
def main(page: ft.Page):
    # Configura el tamaño de la ventana de la aplicación
    page.window.width = 400        # Ancho fijo de la ventana
    page.window.height = 680       # Alto fijo de la ventana
    page.window.resizable = False  # La ventana no se puede redimensionar
    page.update()                  # Actualiza la interfaz para aplicar los cambios

    # Función que se ejecuta cuando cambia la ruta de navegación
    def route_change(e):
        page.views.clear()  # Limpia todas las vistas anteriores

        # Según la ruta, se muestra la vista correspondiente
        if page.route == "/registrar":
            # Vista de registro con opción de volver al login
            page.views.append(registrar_view(page, volver_login=lambda: page.go("/")))
        elif page.route == "/menu":
            vista_menu = menu_principal(
                page,
                lambda imagen, enfermedad, fecha, tratamiento: ir_a_info_con_datos(imagen, enfermedad, fecha, tratamiento),
                lambda e: page.go("/crud_user"),
                lambda e: page.go("/abrir_camara")
            )
            page.views.append(vista_menu)

                                            
        elif page.route == "/crud_user":
            page.views.append(crud_user(page, volver_al_menu=lambda e: page.go("/menu")))

        elif page.route == "/abrir_camara":
            page.views.append(abrir_camara(page, lambda: page.go("/menu")))

        elif page.route == "/crud_user":
            page.views.append(crud_user(page, volver_al_menu=lambda e: page.go("/menu")))

            # Vista del menú principal con opción de ir a la información detallada
            #page.views.append(menu_principal(page, go_to_info=lambda: page.go("/info")))
        elif page.route == "/info":
            datos = page.session.get("datos_info")
            if datos:
                page.views.append(info_detallada(page))
            else:
                page.views.append(ft.View(
                    route="/info",
                    controls=[ft.Text("No se encontraron datos para mostrar la información detallada.", color="red")]
                ))
        elif page.route == "/reset":
            page.views.append(reset_contraseña_view(page, volver_login=lambda: page.go("/")))
        else:
            # Vista por defecto (login), con navegación a registrar o al menú
            page.views.append(login_view(
                page,
                go_to_registrar=lambda: page.go("/registrar"),
                go_to_menu=lambda: page.go("/menu"),
                go_to_reset=lambda: page.go("/reset")
            ))

        page.update()  # Se actualiza la página con la nueva vista

    def ir_a_info_con_datos(imagen, enfermedad, fecha, tratamiento):
        page.session.set("datos_info", {
            "imagen": imagen,
            "enfermedad": enfermedad,
            "fecha": fecha,
            "tratamiento": tratamiento
        })
        page.go("/info")

    page.on_route_change = route_change  # Asocia la función al evento de cambio de ruta
    page.go("/")  # Navega inicialmente a la ruta raíz (login)

# Lanza la aplicación con la función `main` como punto de entrada
ft.app(target=main)
